package game;

import service.Set;
import ui.ClockPanel;


public class DoubleMode extends Mode{
	
	
	
	public DoubleMode(Set s){
		super(s);
		restTime = -1; 
		// TODO Auto-generated constructor stub
	}

	public void go() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}

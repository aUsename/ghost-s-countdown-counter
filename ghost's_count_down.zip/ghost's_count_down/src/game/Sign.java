package game;

public class Sign {
    public boolean sign = false;
}

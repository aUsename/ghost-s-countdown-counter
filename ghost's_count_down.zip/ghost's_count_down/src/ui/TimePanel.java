package ui;

import java.awt.LayoutManager;

import javax.swing.JPanel;

public class TimePanel extends JPanel {

	public TimePanel() {
		// TODO Auto-generated constructor stub
	}

	public TimePanel(LayoutManager layout) {
		super(layout);
		// TODO Auto-generated constructor stub
	}

	public TimePanel(boolean isDoubleBuffered) {
		super(isDoubleBuffered);
		// TODO Auto-generated constructor stub
	}

	public TimePanel(LayoutManager layout, boolean isDoubleBuffered) {
		super(layout, isDoubleBuffered);
		// TODO Auto-generated constructor stub
	}

}

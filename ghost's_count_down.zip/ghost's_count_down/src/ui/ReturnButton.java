package ui;

import javax.swing.JButton;

public class ReturnButton extends JButton {
  public  ReturnButton(){
	  
  }
}

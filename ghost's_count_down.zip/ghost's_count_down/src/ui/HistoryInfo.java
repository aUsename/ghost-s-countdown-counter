package ui;

import java.awt.LayoutManager;

import javax.swing.JPanel;

public class HistoryInfo extends JPanel {

	public HistoryInfo() {
		// TODO Auto-generated constructor stub
	}

	public HistoryInfo(LayoutManager layout) {
		super(layout);
		// TODO Auto-generated constructor stub
	}

	public HistoryInfo(boolean isDoubleBuffered) {
		super(isDoubleBuffered);
		// TODO Auto-generated constructor stub
	}

	public HistoryInfo(LayoutManager layout, boolean isDoubleBuffered) {
		super(layout, isDoubleBuffered);
		// TODO Auto-generated constructor stub
	}

}
